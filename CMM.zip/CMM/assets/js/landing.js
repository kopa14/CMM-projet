// landing.js

// Charge les formulaires depuis le localStorage
function loadForms() {
    return JSON.parse(localStorage.getItem('forms') || '[]');
  }
  
  // Enregistre le tableau mis à jour dans le localStorage
  function saveForms(forms) {
    localStorage.setItem('forms', JSON.stringify(forms));
  }
  
  // Affiche la liste des formulaires enregistrés
  function displayForms(forms) {
    const formsList = document.getElementById('formsList');
    formsList.innerHTML = '';
    if (forms.length === 0) {
      const li = document.createElement('li');
      li.textContent = "Aucun formulaire enregistré.";
      formsList.appendChild(li);
      return;
    }
    forms.forEach((form, index) => {
      const li = document.createElement('li');
  
      // Zone d'information : nom + date
      const infoSpan = document.createElement('span');
      infoSpan.textContent = form.name + " (" + new Date(form.timestamp).toLocaleString() + ")";
      li.appendChild(infoSpan);
  
      // Bouton de suppression remplacé par une icône
        const delBtn = document.createElement('img');
        delBtn.src = "/assets/images/trash.png"; // Mets ici le chemin de ton icône
        delBtn.alt = "Supprimer";
        delBtn.className = "delete-icon";
        delBtn.addEventListener('click', (e) => {
        e.stopPropagation(); // Empêche le déclenchement de l'événement sur le li
        if (confirm("Supprimer ce formulaire ?")) {
            deleteForm(index);
        }
        });
        li.appendChild(delBtn);

  
      // Cliquer sur le li (hors bouton) charge le formulaire
      li.addEventListener('click', () => {
        localStorage.setItem('selectedForm', JSON.stringify(form));
        window.location.href = "form.html";
      });
  
      formsList.appendChild(li);
    });
  }
  
  // Supprime un formulaire en fonction de son index
  function deleteForm(index) {
    let forms = loadForms();
    forms.splice(index, 1);
    saveForms(forms);
    displayForms(forms);
  }
  
  // Filtre les formulaires selon la recherche
  function searchForms(query) {
    let forms = loadForms();
    if (query) {
      forms = forms.filter(form => form.name.toLowerCase().includes(query.toLowerCase()));
    }
    displayForms(forms);
  }
  
  // Écoute de la barre de recherche
  document.getElementById('searchBar').addEventListener('input', function() {
    searchForms(this.value);
  });
  
  
  document.getElementById('newFormButton').addEventListener('click', function() {
    localStorage.removeItem('selectedForm');
    // Rediriger vers la page de choix de formulaire
    window.location.href = "chooseForm.html";
  });
  
  
  // Au chargement, affiche tous les formulaires
  document.addEventListener('DOMContentLoaded', () => {
    displayForms(loadForms());
  });
  