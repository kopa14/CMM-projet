
document.addEventListener('DOMContentLoaded', function() {
  // Fonction générique de mise à jour du score pour un formulaire donné
  function updateScore(formId, resultId) {
    const form = document.getElementById(formId);
    form.addEventListener('change', function() {
      let total = 0;
      const selects = form.querySelectorAll('select');
      selects.forEach(select => {
        const weight = select.options[select.selectedIndex].getAttribute('data-weight');
        if (weight !== null && weight !== "") {
          total += parseInt(weight, 10);
        }
      });
      document.getElementById(resultId).textContent = "Total score: " + total;
    });
  }

  // Mise à jour des scores pour chaque section
  updateScore('form-profil', 'total-score-profil');
  updateScore('form-strategie', 'total-score-strategie');
  updateScore('form-marketing', 'total-score-marketing');
  updateScore('form-logistique', 'total-score-logistique');
  updateScore('form-reglementation', 'total-score-reglementation');
  updateScore('form-paiement', 'total-score-paiement');
  updateScore('form-sav', 'total-score-sav');
  updateScore('form-technologies', 'total-score-technologies');

  // Génération du PDF lors du clic sur le bouton Envoyer
  document.getElementById("submitButton").addEventListener("click", function() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({
      orientation: "p",
      unit: "mm",
      format: "a4"
    });

    let marginLeft = 15;
    let pageWidth = doc.internal.pageSize.width - 2 * marginLeft;
    let yPosition = 30;
    let lineHeight = 6;
    let pageHeight = doc.internal.pageSize.height;
    let pageNumber = 1;

    // Fonction pour ajouter un en-tête
    function addHeader() {
      doc.setFillColor(0, 102, 204);
      doc.rect(0, 0, doc.internal.pageSize.width, 20, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(18);
      doc.text("Questionnaire Rempli", doc.internal.pageSize.width / 2, 13, { align: "center" });
      doc.setTextColor(0, 0, 0);
    }

    // Fonction pour ajouter un pied de page
    function addFooter() {
      doc.setFont("times", "italic");
      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text(`Page ${pageNumber}`, doc.internal.pageSize.width - 20, doc.internal.pageSize.height - 10);
    }

    addHeader();

    let sections = ["profil", "strategie", "marketing", "logistique", "reglementation", "paiement", "sav", "technologies"];

    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text("Questionnaire Rempli", marginLeft, yPosition);
    yPosition += 10;

    sections.forEach(section => {
      // Récupération du titre de la section
      let sectionHeader = document.querySelector(`#section-${section} h2`);
      if (!sectionHeader) return;
      let sectionTitle = fixEncoding(sectionHeader.innerText);

      // Si on dépasse la page, on ajoute un pied de page et une nouvelle page
      if (yPosition + 10 > pageHeight) {
        addFooter();
        doc.addPage();
        pageNumber++;
        yPosition = 30;
        addHeader();
      }
      // Ajout d’un encadré derrière le titre de la section
      doc.setFillColor(230, 230, 230);
      doc.rect(marginLeft - 5, yPosition - 5, pageWidth + 10, 8, "F");
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text(sectionTitle, marginLeft, yPosition);
      yPosition += 10;

      // Parcours des questions de la section
      const questions = document.querySelectorAll(`#form-${section} .question`);
      questions.forEach(questionDiv => {
        let questionElement = questionDiv.querySelector('p');
        let answerElement = questionDiv.querySelector('select, input[type="text"]');
        if (!questionElement || !answerElement) return;
        let questionText = fixEncoding(questionElement.innerText);
        let answerText = getAnswerText(answerElement);

        if (yPosition + 15 > pageHeight) {
          addFooter();
          doc.addPage();
          pageNumber++;
          yPosition = 30;
          addHeader();
        }

        // Ajout de la question
        doc.setFont("helvetica", "bold");
        doc.setFontSize(10);
        let questionLines = doc.splitTextToSize("Q: " + questionText, pageWidth);
        doc.text(questionLines, marginLeft, yPosition);
        yPosition += questionLines.length * lineHeight;

        // Ajout de la réponse
        doc.setFont("helvetica", "normal");
        doc.setFontSize(10);
        let answerLines = doc.splitTextToSize("Réponse: " + answerText, pageWidth);
        doc.text(answerLines, marginLeft, yPosition);
        yPosition += answerLines.length * lineHeight + 3;
      });

      yPosition += 5;
    });

    addFooter();
    doc.save("questionnaire_rempli.pdf");
  });

  // Fonction pour corriger l'encodage du texte
  function fixEncoding(text) {
    return text
      .replace(/\uFFFD/g, '')
      .replace(/[\u2018\u2019]/g, "'")
      .replace(/[\u201C\u201D]/g, '"')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Fonction pour récupérer le texte de la réponse en toute sécurité
  function getAnswerText(element) {
    if (element.tagName.toLowerCase() === "select") {
      let selectedOption = element.options[element.selectedIndex];
      return selectedOption ? fixEncoding(selectedOption.text) : "Non répondu";
    } else {
      return fixEncoding(element.value || "Non répondu");
    }
  }
});


document.addEventListener('DOMContentLoaded', () => {
  // Flag indiquant si le formulaire a été sauvegardé
  let formSaved = false;

  // Charge les données sauvegardées dans tous les formulaires présents sur la page
  function loadSelectedForm() {
    const selectedForm = localStorage.getItem('selectedForm');
    if (selectedForm) {
      const data = JSON.parse(selectedForm);
      // data est un objet avec pour clés les id des formulaires (ex. "form-profil", "form-marketing", …)
      for (const formId in data) {
        const form = document.getElementById(formId);
        if (form) {
          const formData = data[formId];
          for (const key in formData) {
            if (form.elements[key]) {
              form.elements[key].value = formData[key];
            }
          }
        }
      }
    }
  }

  // Récupère les données de tous les formulaires présents sur la page
  function getAllFormData() {
    const data = {};
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
      const id = form.id;
      data[id] = {};
      Array.from(form.elements).forEach(el => {
        if (el.name) {
          data[id][el.name] = el.value;
        }
      });
    });
    return data;
  }

  // Sauvegarde le formulaire en demandant un nom à l'utilisateur
  function saveForm() {
    const data = getAllFormData();
    const formName = prompt("Donnez un nom à ce formulaire");
    if (!formName) {
      alert("Vous devez fournir un nom pour sauvegarder le formulaire.");
      return;
    }
    let forms = JSON.parse(localStorage.getItem('forms') || '[]');
    forms.push({ name: formName, timestamp: Date.now(), data: data });
    localStorage.setItem('forms', JSON.stringify(forms));
    formSaved = true;
    alert("Formulaire sauvegardé !");
  }

  // Retourne à la page liste avec une alerte si le formulaire n'a pas été sauvegardé
  function returnToList() {
    if (!formSaved) {
      const confirmReturn = confirm("Attention, vous n'avez pas sauvegardé le formulaire. Voulez-vous vraiment quitter ?");
      if (!confirmReturn) {
        return;
      }
    }
    localStorage.removeItem('selectedForm');
    window.location.href = "index.html";
  }

  // Génère un PDF en parcourant tous les formulaires de la page
  function generatePDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    let yPosition = 20;
    doc.setFontSize(12);
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
      const formId = form.id;
      // Ajout du titre du formulaire (son id)
      doc.text(formId + ":", 10, yPosition);
      yPosition += 10;
      Array.from(form.elements).forEach(el => {
        if (el.name) {
          let textLine = el.name + ": " + el.value;
          doc.text(textLine, 15, yPosition);
          yPosition += 10;
        }
      });
      yPosition += 10; // Espace entre les formulaires
    });
    doc.save("formulaire.pdf");
  }

  // Attache les écouteurs d'événements aux boutons
  const saveButton = document.getElementById('saveButton');
  if (saveButton) {
    saveButton.addEventListener('click', saveForm);
  }

  const returnButton = document.getElementById('returnButton');
  if (returnButton) {
    returnButton.addEventListener('click', returnToList);
  }

  const pdfButton = document.getElementById('pdfButton');
  if (pdfButton) {
    pdfButton.addEventListener('click', generatePDF);
  }

  // Charge les données sauvegardées dans les formulaires s'il y en a
  loadSelectedForm();
});
